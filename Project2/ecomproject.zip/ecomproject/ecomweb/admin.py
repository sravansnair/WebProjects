from django.contrib import admin
from . models import table1, table2
# Register your models here.
admin.site.register(table1),
admin.site.register(table2)
